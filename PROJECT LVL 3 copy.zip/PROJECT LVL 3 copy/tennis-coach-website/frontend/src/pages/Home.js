import useStore from '../store';
import useFetchBookings from '../hooks/useFetchBookings';

function Home() {
  const { user, bookings } = useStore();
  useFetchBookings();

  const lessonsCount = bookings.length;

  return (
    <div className="max-w-6xl mx-auto p-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-pink-100 p-8 rounded-lg shadow">
          <h2 className="text-2xl font-bold mb-4">Improvement Over Time</h2>
          {user ? (
            <p className="text-lg">You have taken <strong>{lessonsCount}</strong> lessons</p>
          ) : (
            <p>Register to track your progress!</p>
          )}
        </div>

        <div className="bg-orange-100 p-8 rounded-lg shadow">
          <h2 className="text-2xl font-bold mb-4">Top Students Ranking</h2>
          <ul className="space-y-2 text-lg">
            <li>🏆 Alex Dill - 3.0 NTRP</li>
            <li>🥈 Gemma Sun - 2.5 NTRP</li>
            <li>🥉 Your Name? - Join now!</li>
          </ul>
        </div>

        <div className="bg-blue-100 p-8 rounded-lg shadow text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to improve?</h2>
          {!user && (
            <p className="text-lg mb-4">Register for personal tracking and booking</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default Home;