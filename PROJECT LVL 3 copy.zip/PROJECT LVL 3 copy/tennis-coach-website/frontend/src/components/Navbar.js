import { Link, useNavigate } from 'react-router-dom';
import useStore from '../store';

function Navbar() {
  const { user, logout } = useStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-yellow-400 p-6 shadow-lg">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        <div className="text-3xl font-bold text-white">Tennis Lessons with Danil</div>
        <div className="space-x-6 text-lg">
          <Link to="/background" className="text-white hover:underline">My Background</Link>
          <Link to="/lessons" className="text-white hover:underline">Lessons</Link>
          <Link to="/rates" className="text-white hover:underline">Rates/Packages</Link>
          {user && <Link to="/bookings" className="text-white hover:underline">My Bookings</Link>}
        </div>
        <div className="space-x-4">
          {user ? (
            <button onClick={handleLogout} className="bg-red-500 text-white px-5 py-2 rounded hover:bg-red-600">Logout</button>
          ) : (
            <>
              <Link to="/login" className="bg-green-500 text-white px-5 py-2 rounded hover:bg-green-600">Log in</Link>
              <Link to="/register" className="bg-pink-500 text-white px-5 py-2 rounded hover:bg-pink-600">Register</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Navbar;