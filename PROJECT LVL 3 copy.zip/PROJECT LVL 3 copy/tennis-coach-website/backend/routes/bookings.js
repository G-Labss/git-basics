const express = require('express');
const auth = require('../middleware/auth');
const { validateBooking } = require('../middleware/validate');
const { createBooking, getBookings, getBookingById, updateBooking, deleteBooking } = require('../controllers/bookings');

const router = express.Router();
router.use(auth);

router.post('/', validateBooking, createBooking);
router.get('/', getBookings);
router.get('/:id', getBookingById);
router.put('/:id', validateBooking, updateBooking);
router.delete('/:id', deleteBooking);

module.exports = router;