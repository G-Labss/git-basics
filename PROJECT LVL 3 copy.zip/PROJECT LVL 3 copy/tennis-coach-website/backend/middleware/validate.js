const Joi = require('joi');

const validateBooking = (req, res, next) => {
  const schema = Joi.object({
    lessonType: Joi.string().required(),
    date: Joi.date().iso().required(),
  });
  const { error } = schema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });
  next();
};

module.exports = { validateBooking };