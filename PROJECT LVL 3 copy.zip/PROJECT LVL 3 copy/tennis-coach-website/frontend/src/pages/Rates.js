function Rates() {
  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-4xl font-bold mb-6">Rates & Packages</h1>
      <p className="text-lg">Single lesson: $80/hour<br />5-pack: $375<br />10-pack: $700</p>
    </div>
  );
}
export default Rates;