import { useEffect } from 'react';
import axios from 'axios';
import useStore from '../store';

const useFetchBookings = () => {
  const { setBookings, user } = useStore();

  useEffect(() => {
    if (user) {
      axios.get('http://localhost:5000/api/bookings', {
        headers: { 'x-auth-token': localStorage.getItem('token') }
      })
      .then(res => setBookings(res.data))
      .catch(err => console.error(err));
    }
  }, [user, setBookings]);
};

export default useFetchBookings;