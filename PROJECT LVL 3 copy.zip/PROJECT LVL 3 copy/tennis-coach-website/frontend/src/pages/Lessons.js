function Lessons() {
  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-4xl font-bold mb-6">Lessons Offered</h1>
      <p className="text-lg">Private, semi-private, group lessons for all levels.</p>
    </div>
  );
}
export default Lessons;