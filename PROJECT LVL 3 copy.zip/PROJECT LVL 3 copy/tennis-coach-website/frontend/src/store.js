import { create } from 'zustand';

const useStore = create((set) => ({
  user: null,
  bookings: [],
  setUser: (user) => set({ user }),
  setBookings: (bookings) => set({ bookings }),
  logout: () => {
    localStorage.removeItem('token');
    set({ user: null, bookings: [] });
  },
}));

export default useStore;