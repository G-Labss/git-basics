function Background() {
  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-4xl font-bold mb-6">My Background</h1>
      <p className="text-lg leading-relaxed">10+ years coaching experience, former college player, certified coach...</p>
    </div>
  );
}
export default Background;